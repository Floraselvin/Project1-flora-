package mypack;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;

@MultipartConfig
(
		
	location="C:\\NewWorkSpace\\LearnWithJoy\\src\\main\\webapp\\resources\\image",
	fileSizeThreshold=1024*1024,
	maxFileSize=1024*1024*10,
	maxRequestSize=1024*1024*11
		
)
public class createuser<E> extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void service(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{

RequestDispatcher rs;
		
		Configuration cfg = new Configuration();
		Session S = cfg.configure("connect.cfg.xml").buildSessionFactory().openSession();
		
		S.getTransaction().begin();
		String stnm = request.getParameter("stnm");
		String mail = request.getParameter("mail");
		String phno = request.getParameter("phno");
		String fanm = request.getParameter("fanm");
		String manm = request.getParameter("manm");
		String crnm = request.getParameter("crnm");
		int feepay=Integer.parseInt(request.getParameter("feepay"));
		String fnmail = request.getParameter("fnmail");
		String adds = request.getParameter("adds");
		int crid=Integer.parseInt(request.getParameter("crid"));
		
		 Query qry=S.createQuery("from course f where f.crid=:VAL");
	       
	       qry.setParameter("VAL",crid);
	       
	       List L=qry.list();
	       course f=null;
	       Iterator i =L.iterator();
	       while(i.hasNext())
	       {
	    	   f=(course)i.next();
	    	   break;
	    	   
	       }
	       
	       
	       
	       int a=Integer.parseInt(f.getCost());
	       String z=Integer.toString(a-feepay);
	       
	   
	       
		
		
	    String pic=null;
	    String meg=null;
	    
	    
	    try
	    {
	    	Part part=request.getPart("pic");
	    	part.write(filename(part));
	    	meg="success";
	    	pic=filename(part);
	    	
	    }catch (Exception ex)
	    {
	    	meg="Error:"+ex.getMessage();
	    }
	    student u=new student();
	    u.setStnm(stnm);
	    u.setMail(mail);
	    u.setPhno(phno);
	    u.setFanm(fanm);
        u.setManm(manm);
       u.setCrnm(crnm);
       u.setCrid(crid);
    
       u.setFeepay(request.getParameter("feepay"));
       u.setPic(pic);
       u.setFnmail(fnmail);
       u.setAdds(adds);
       u.setDuefee(z);

System.out.println(u);
System.out.println(crnm+" "+stnm+" "+pic);
	    S.save(u);
	    S.getTransaction().commit();
	    System.out.println(f);
	    
	    S.close();
	    //request.setAttribute("message", meg);
	    request.getRequestDispatcher("/submission.jsp").forward(request, response);
		
	}

	private String filename(Part part) {
		 String disposition=part.getHeader("content-disposition");
		 if(!disposition.contains("filename=")) {
			 return null;
		 }
		 int beginIndex = disposition.indexOf("filename=") + 10;
		 int lastIndex = disposition.length()-1;
		 
		 return disposition.substring(beginIndex, lastIndex);
		 
	 }

}
