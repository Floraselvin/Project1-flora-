package mypack;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;


@Entity
@Table(name="course",uniqueConstraints = {
        @UniqueConstraint(columnNames = "crid")
        })
public class course {
	
	@Id	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int crid;
	
	@Column(name="crnm")
	private String crnm;
	
	@Column(name="pic")
	private String pic;
	
	
	
	public String getPic() {
		return pic;
	}

	public void setPic(String pic) {
		this.pic = pic;
	}

	@Column(name="cost")
	private String cost;
	
	@Column(name="description")
	private String description;

	public int getCrid() {
		return crid;
	}

	public void setCrid(int crid) {
		this.crid = crid;
	}

	public String getCrnm() {
		return crnm;
	}

	public void setCrnm(String crnm) {
		this.crnm = crnm;
	}

	public String getCost() {
		return cost;
	}

	public void setCost(String cost) {
		this.cost = cost;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	public String toString()
	{
		return getCrid()+""+getCrnm()+""+getCost()+""+getDescription()+""+getPic();
	}
	
	
	
	

}
