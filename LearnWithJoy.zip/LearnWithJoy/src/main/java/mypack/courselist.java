package mypack;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;

@MultipartConfig
(
		
	location="C:\\NewWorkSpace\\LearnWithJoy\\src\\main\\webapp\\resources\\coursefolder",
	fileSizeThreshold=1024*1024,
	maxFileSize=1024*1024*10,
	maxRequestSize=1024*1024*11
		
)
public class courselist extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void service(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{

RequestDispatcher rs;
		
		Configuration cfg = new Configuration();
		Session S = cfg.configure("connect.cfg.xml").buildSessionFactory().openSession();
		
		S.getTransaction().begin();
		
		String crnm = request.getParameter("crnm");
		String cost = request.getParameter("cost");
		String description = request.getParameter("description");
		
		
		 String pic=null;
		    String meg=null;
		    
		    
		    try
		    {
		    	Part part=request.getPart("pic");
		    	part.write(filename(part));
		    	meg="success";
		    	pic=filename(part);
		    	
		    }catch (Exception ex)
		    {
		    	meg="Error:"+ex.getMessage();
		    }
		    
		    course u= new course();
		    u.setCrnm(crnm);
		    u.setCost(cost);
		    u.setDescription(description);
		    u.setPic(pic);
		
		    S.save(u);
		    S.getTransaction().commit();
		    
		    
		    S.close();
		    //request.setAttribute("message", meg);
		    request.getRequestDispatcher("/HomePage.jsp").forward(request, response);
			
		}

		private String filename(Part part) {
			 String disposition=part.getHeader("content-disposition");
			 if(!disposition.contains("filename=")) {
				 return null;
			 }
			 int beginIndex = disposition.indexOf("filename=") + 10;
			 int lastIndex = disposition.length()-1;
			 
			 return disposition.substring(beginIndex, lastIndex);
			 
		 }

	}
