package mypack;
import javax.persistence.*;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;


@Entity
@Table(name="student",uniqueConstraints = {
        @UniqueConstraint(columnNames = "stid")
        })

public class student{
	
	@Id	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int stid;
	
	@Column(name="stnm")
	private String stnm;
	
	@Column(name="mail")
	private String mail;
	
	@Column(name="phno")
	private String phno;
	
	@Column(name="fanm")
	private String fanm;
	
	@Column(name="manm")
	private String manm;
	
	@Column(name="crnm")
	private String crnm;
	
	@Column(name="crid")
	private int crid;
	
	@Column(name="feepay")
	private String feepay;
	
	@Column(name="pic")
	private String pic;
	
	@Column(name="fnmail")
	private String fnmail;
	
	@Column(name="adds")
	private String adds;
	
	
	
	@Column(name="duefee")
	private String duefee;
	
	

	public String getDuefee() {
		return duefee;
	}

	public void setDuefee(String duefee) {
		this.duefee = duefee;
	}

	public int getCrid() {
		return crid;
	}

	public void setCrid(int crid) {
		this.crid = crid;
	}

	public int getStid() {
		return stid;
	}

	public void setStid(int stid) {
		this.stid = stid;
	}

	public String getStnm() {
		return stnm;
	}

	public void setStnm(String stnm) {
		this.stnm = stnm;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getPhno() {
		return phno;
	}

	public void setPhno(String phno) {
		this.phno = phno;
	}

	public String getFanm() {
		return fanm;
	}

	public void setFanm(String fanm) {
		this.fanm = fanm;
	}

	public String getManm() {
		return manm;
	}

	public void setManm(String manm) {
		this.manm = manm;
	}

	public String getCrnm() {
		return crnm;
	}

	public void setCrnm(String crnm) {
		this.crnm = crnm;
	}

	public String getFeepay() {
		return feepay;
	}

	public void setFeepay(String feepay) {
		this.feepay = feepay;
	}

	public String getPic() {
		return pic;
	}

	public void setPic(String pic) {
		this.pic = pic;
	}

	public String getFnmail() {
		return fnmail;
	}

	public void setFnmail(String fnmail) {
		this.fnmail = fnmail;
	}

	public String getAdds() {
		return adds;
	}

	public void setAdds(String adds) {
		this.adds = adds;
	}
	
	public String toString()
	{
		return getStid()+""+getStnm()+""+getMail()+""+getPhno()+""+getFanm()+""+getManm()+""+getCrnm()+""+getFeepay()+""+getPic()+""+getFnmail()+""+getAdds()+""+getCrid()+""+getDuefee();
	}
}